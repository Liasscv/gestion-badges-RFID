﻿Imports System.Net.Sockets
Imports System.Text
Module Module1
    Sub Main()
        Dim serverSocket As New TcpListener(6666)
        Dim clientSocket As TcpClient
        Dim counter As Integer

        Console.Title = "Server Demo"
        ' Start server
        serverSocket.Start()
        Console.WriteLine("Server running...")

        ' Client counter
        counter = 0

        While (True)
            counter += 1

            ' Wait for client connections
            clientSocket = serverSocket.AcceptTcpClient()
            Console.WriteLine("Client " + Convert.ToString(counter) + " connected!")

            ' Client connected, start a thread for it
            Dim client As New handleClinet
            client.startClient(clientSocket, Convert.ToString(counter))

        End While

        ' Close connections
        clientSocket.Close()
        serverSocket.Stop()
        Console.WriteLine("Socket closed")
        Console.ReadLine()
    End Sub

    Public Class handleClinet
        Dim clientSocket As TcpClient
        Dim clNo As String

        Public Sub startClient(ByVal inClientSocket As TcpClient, ByVal clineNo As String)
            Me.clientSocket = inClientSocket
            Me.clNo = clineNo
            ' Start a thread to handle client requests
            Dim ctThread As Threading.Thread = New Threading.Thread(AddressOf HandleClientComm)
            ctThread.Start()
        End Sub

        Private Sub HandleClientComm()
            Dim bytesFrom(10024) As Byte
            Dim dataFromClient As String
            Dim sendBytes As [Byte]()
            Dim serverResponse As String
            Dim devID As String
            Dim unixTimeStamp As Integer
            Dim networkStream As NetworkStream
            Dim clientDataLen As Integer

            While (True)
                Try
                    ' Start stream and wait data
                    networkStream = clientSocket.GetStream()
                    clientDataLen = clientSocket.Available

                    ' Ignore zero messages
                    If clientDataLen = 0 Then
                        Continue While
                    End If

                    unixTimeStamp = DateTime.Now.Subtract(New DateTime(1970, 1, 1)).TotalSeconds

                    ' Get data from client
                    networkStream.Read(bytesFrom, 0, clientDataLen)
                    dataFromClient = Encoding.ASCII.GetString(bytesFrom, 0, clientDataLen)
                    Console.ForegroundColor = ConsoleColor.White
                    Console.WriteLine("Client data: " + dataFromClient)

                    ' Connected reader ID
                    devID = dataFromClient.Substring(0, dataFromClient.IndexOf(","))

                    ' Prepare answer message
                    serverResponse = devID + ",RELAY1=500,BUZZER;50;2,LCDCLR,LCDSET;10;20;2;MCR02 TEST OK,LCDSET;10;35;1;Ottron Technology" + ",TSYNC=" + unixTimeStamp.ToString
                    sendBytes = Encoding.ASCII.GetBytes(serverResponse)

                    ' Send answer to client
                    networkStream.Write(sendBytes, 0, sendBytes.Length)
                    networkStream.Flush()

                    ' Highlight server data
                    Console.ForegroundColor = ConsoleColor.Yellow
                    Console.WriteLine("Server data: " + serverResponse)

                    ' Set forecolor back
                    Console.ForegroundColor = ConsoleColor.Gray

                Catch ex As Exception
                    ' Exception occured
                    MsgBox(ex.ToString)

                End Try
            End While
        End Sub
    End Class
End Module