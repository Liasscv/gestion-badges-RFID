/*
TCP/IP Server By MinovaTech 
June 2018

Includes simple command handler for MCR04 series of TCP/IP contactless readers

Sample Incoming Packet : 
MCR02-8A914F,UID=1050892180,BLOCK=0000000000000011,IO=0F

Server-Reply
MCR02-8A914F,RELAY1=1500,LCDCLR,LCDSET;10;20;2;Node.js Server,LCDSET;10;35;1;Test OK!,LCDUNLOCK,TSYNC=1529776939
 
Sample Alive Message
MCR02-8A914F,ALIVE,IO=0F
*/


	var net = require('net');														//this is a required node js libraryfor TCP/IP socket 
																							//use npm (node packet manager) console command to download & install the lib
																							//console command : npm install net

	var hostIP = '46.101.152.212';												//your server IP
	var hostPort = 8120;															//your server Port

	var server = net.createServer(function (socket) {					//TCP/IP server object to handle almost all the tasks
				
		// Identify this client
		socket.name = socket.remoteAddress + ":" + socket.remotePort; 

		console.log('client is here ' + socket.name);		
		
		socket.setTimeout(100000);											//connection iddle timeout ms
		
		socket.on('error', function() {
			console.log('socket error');
			});
		
		socket.on('end', function() {
			console.log('client disconnected');
			});
		
		socket.on('data', function(data) {										//socket data receive event
			var str = String(data);													//stringify incoming data
			console.log(str);
			
			var prt = str.split(',');													//split incoming command into parts

			console.log(prt);

			if(prt[1] == "ALIVE"){
				//here we do nothing, just to keep socket alive
				}
			else{	
				var deviceID = prt[0];												//first part is allways device id
				var uid = prt[1];														//2nd part is card uid
				
				//if(prt[2] != null)														//3rd part is optional, exist is device is set to read desired block
					//var block = prt[2];			
				
				//if(prt[3] != null)														//check if IO part exist in incoming string
				//var io = prt[3];

				var d = new Date();													//lets create unixtime 
				unixTime = Math.floor(d.getTime() / 1000);				//unixtime in seconds
				unixTime += 3600 * 3;											//timezone adjust (can be done in better ways, this is for convenience)
			
				//now we are ready to create reply string. Here some parameters seem to be hardcoded, they can easily be set by variables as in TSYNC or Relay time
				var relayTime= 1500;
				
				var reply = deviceID + ',' + ",RELAY1="+relayTime+",LCDCLR,BUZZER;100;2,LCDSET;10;20;2;Node.js Server,LCDSET;10;35;1;Test OK!,LCDUNLOCK,TSYNC="+unixTime;

				socket.write(reply);												//send reply to existing socket
				}

			});
		});

	server.listen(hostPort, hostIP, function(){							//program entry point for TCP/IP server 
		console.log("Server is listening, IP : "+hostIP+" port : "+hostPort);
		});	
