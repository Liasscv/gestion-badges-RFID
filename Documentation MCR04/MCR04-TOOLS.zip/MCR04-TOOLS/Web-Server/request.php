
<?php 
//require_once('Connections/etrace_db.php'); 
?>

<?php
	date_default_timezone_set('Europe/Berlin');
		
	$datetime = date("Y-m-d H:i:s");
		
	if(isset($_GET['cmd']))													
	{
		$cmd = $_GET['cmd'];												
		$devID = $_GET['devID'];											
		
		if($cmd == "ALIVE")													
		{							
			$year = date("Y");												
			$month = date("m");
			$day = date("d");
			$hour = date("H");
			$minute = date("i");
			$sec = date("s");
			
			echo $devID.",BUZZER;100;1";
		}
		else if($cmd == "OFFLINE")											
		{
			echo $devID.",OFF_ACK";										
		}
		else if($cmd == "LOGIN")
		{
			echo $devID.",LOGIN_ACK";
		}
		else if($cmd == "KEYREQ")											
		{
			echo $devID.",KEY;A0A1A2A3A4A5";							
		}
	}
	else if(isset($_GET['uid']))
	{
		$uid = $_GET['uid'];
		
		if(isset($_GET['devID']))
			$devID = $_GET['devID'];
		else
			$devID = 1;
		
		echo $devID.",BUZZER;100;1,RELAY1=1000,RELAY2=2000,LCDCLR,LCDSET;0;20;2;MINOVA Php Test!,LCDSET;0;40;2;Test OK!";
		
	}
?>


	
