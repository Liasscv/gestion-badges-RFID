﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace GSAUpdater
{
    class ServerLogger
    {
        public bool LogtoFile(string arac_no,string data)
        {
            string path = @"LOG" + "\\" + arac_no;

            Console.WriteLine(data);

            try
            {
                // Determine whether the directory exists.
                if (!Directory.Exists(path))
                {
                    // Try to create the directory.
                    DirectoryInfo di = Directory.CreateDirectory(path);
                    Console.WriteLine("Log folder created: {0}.", Directory.GetCreationTime(path));
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("The process failed: {0}", e.ToString());
            }

            string shortDateString = DateTime.Now.ToShortDateString();

            string logMessage = DateTime.Now + ": " + data;

            using (StreamWriter w = File.AppendText(path + "\\" + shortDateString + ".txt"))
            {
                w.WriteLine(logMessage);
                // Update the underlying file.
                w.Flush();
                // Close the writer and underlying file.
                w.Close();
            }

            return true;
        }
    }
}
