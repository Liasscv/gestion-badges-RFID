﻿using System.Collections.Generic;
using System.Linq;
using System.Text;
using System;
using System.IO;
using System.Net.Sockets;
using System.Collections;
using System.Threading;
using System.Net;
using System.Data.SqlClient;
using MySql.Data.MySqlClient;
using System.Security.Cryptography;

namespace GSAUpdater
{
    class Program
    {
        private static TcpListener tcpListener;
        private static Thread listenThread;
        
        public volatile static int NumberofClients;
        static readonly object _locker = new object();

        public static string msUser;
        public static string msPass;
        public static string msURL;

        public static string myUser;
        public static string myPass;
        public static string myURL;
        public static string serverPORT;
        public static int cFlag;

        public static string WelcomeMessage;

        private static void ListenForClients()
        {
            tcpListener.Start();

            while (true)
            {
                //blocks until a client has connected to the server
                TcpClient client = tcpListener.AcceptTcpClient();

                //create a thread to handle communication 
                //with connected client
                Thread clientThread = new Thread(new ParameterizedThreadStart(HandleClientComm));
                clientThread.Start(client);

                Thread.Sleep(10);
            }
        }

        
       // This method's signature must match the TimerCallback delega
        private static void OutBoxHandler(Object state)
        {
            // This method is executed by a thread pool thread
        }

        /*
         * // get your files (names)
            string[] fileNames = Directory.GetFiles("c:\\Temp\\", "*.*");

            // Now read the creation time for each file
            DateTime[] creationTimes = new DateTime[fileNames.Length];
            for (int i=0; i < fileNames.Length; i++)
            creationTimes[i] = new FileInfo(fileNames[i]).CreationTime;

            // sort it
            Array.Sort(creationTimes,fileNames);

            // and print for test
            Console.WriteLine("Files ordered by creation time");
            for (int i=0; i < fileNames.Length; i++)
                Console.WriteLine("{0}: {1}", creationTimes[i], fileNames[i]);

         */

        private static void HandleClientComm(object client)
        {
            string data = null;
            TcpClient tcpClient = (TcpClient)client;
            NetworkStream clientStream = tcpClient.GetStream();
            tcpClient.ReceiveTimeout = 90 * 1000;
            byte[] message = new byte[4096];
            int bytesRead;
            string devID = "";
            string ioState = "";
            string aliveMsg = "";
            string tagUID = "";
            string ipNumber = "";
            string mcrReply = "";
            string ServerEchoStr = "";
            Int32 unixTimestamp;

            ServerLogger AddLog = new ServerLogger();
            INIFile ini = new INIFile("Updater.ini"); 

            ipNumber = ((IPEndPoint)tcpClient.Client.RemoteEndPoint).Address.ToString();

            AddLog.LogtoFile("Server", "Received Socket Connection...IP Number: " + ipNumber);
            
            ++NumberofClients;
            
            while (true)
            {
                bytesRead = 0;
                data = "";

                try
                {
                    //blocks until a client sends a message
                    bytesRead = clientStream.Read(message, 0, 4096);
                    data = Encoding.ASCII.GetString(message, 0, bytesRead);
                }
                catch
                {
                    AddLog.LogtoFile("Server", "Data Receive Error: " + data);
                    AddLog.LogtoFile("Server", "Data Receive Error Disconnecting Client...1");
                    break;
                }

                if (bytesRead == 0)
                {
                    AddLog.LogtoFile("Server", "Client Disconnedted From Server...2");
                    break;
                }

                data = data.Trim(); // Remove spaces

                char[] comma = { ',' };
                string[] words = data.Split(comma);

                foreach (string s in words)
                {
                    if (s.Trim() != "")
                    {
                        if (s.Substring(0, 3) == "MCR")
                            devID = s.Trim();                        
                        else if (s.Substring(0, 3) == "V80")
                            devID = s.Trim();                        
                        else if (s.Substring(0, 3) == "ALI")   // Alive message
                             aliveMsg = s.Trim();                            
                        else if (s.Substring(0, 3) == "IO=")
                            ioState = s.Trim();
                        else if (s.Substring(0, 3) == "UID")
                            tagUID = s.Trim();                
                    }
                }

                if(tagUID!="")
                    ServerEchoStr = ini.IniReadValue("SERVER_ECHO", "TAG_STRING");
                else if (aliveMsg != "")
                    ServerEchoStr = " ";
                else if (ioState != "")
                {
                    if(ioState=="IO=0F")
                        ServerEchoStr = ini.IniReadValue("SERVER_ECHO", "IOX_STRING");
                    else if (ioState == "IO=0E")
                        ServerEchoStr = ini.IniReadValue("SERVER_ECHO", "IO0_STRING");
                    else if (ioState == "IO=0D")
                        ServerEchoStr = ini.IniReadValue("SERVER_ECHO", "IO1_STRING");
                    else if (ioState == "IO=0B")
                        ServerEchoStr = ini.IniReadValue("SERVER_ECHO", "IO2_STRING");
                    else if (ioState == "IO=07")
                        ServerEchoStr = ini.IniReadValue("SERVER_ECHO", "IO3_STRING");
                    else
                        ServerEchoStr = ini.IniReadValue("SERVER_ECHO", "IOX_STRING");
                }

                tagUID = "";
                ioState = "";
                aliveMsg = "";
                //devID = words[0];

                //ServerEchoStr = ini.IniReadValue("SERVER_ECHO", "ECHO_STRING");

                unixTimestamp = (Int32)(DateTime.Now.Subtract(new DateTime(1970, 1, 1))).TotalSeconds;

                //mcrReply = devID;
                mcrReply = devID + "," + ServerEchoStr + ",TSYNC=" + unixTimestamp.ToString();

                Console.ForegroundColor = ConsoleColor.White;
                AddLog.LogtoFile("Server", ipNumber + " ; " + devID + " Data From:\n" + data);
                Console.ForegroundColor = ConsoleColor.Green;
                

                //Send a Reply Message
                try
                {
                    byte[] sendBytes = Encoding.ASCII.GetBytes(mcrReply);
                    clientStream.Write(sendBytes, 0, sendBytes.Length);
                    Console.ForegroundColor = ConsoleColor.Gray;
                    AddLog.LogtoFile("Server", ipNumber + " ; " + devID + " Data Sent:\n" + mcrReply);
                    Console.ForegroundColor = ConsoleColor.Green;
                }
                catch
                {
                    AddLog.LogtoFile("Server", "Data Write Error to Socket...");
                    break;
                }

                if ( cFlag != 0 )
                    break;
            }

            Console.ForegroundColor = ConsoleColor.Red;
            AddLog.LogtoFile("Server", "Client Disconnected or Timeout Occured...");
            Console.ForegroundColor = ConsoleColor.Green;

            --NumberofClients;

            //t.Dispose();
            tcpClient.Close();
        }

        // This method's signature must match the TimerCallback delega
        public static void GSATimer(Object state)
        {
            int tmpNumberofClients;

            tmpNumberofClients = NumberofClients;

            //lock (_locker)
            //{
            //    tmpNumberofClients = NumberofClients;
            //}
 
            // This method is executed by a thread pool thread 
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine(DateTime.Now + ": Server Alive...Active Clients Count: " + tmpNumberofClients.ToString());
            Console.ForegroundColor = ConsoleColor.Green;
        }

        static void Main(string[] args)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.Title = "Server Working...Ver.1.5";
            Console.WriteLine("Waiting Connections..");
            Timer t_th = new System.Threading.Timer(new TimerCallback(GSATimer), null, 0, 5000);

            INIFile ini = new INIFile("Updater.ini");

            msUser = ini.IniReadValue("MSSQL", "MS_USER");
            msPass = ini.IniReadValue("MSSQL", "MS_PASS");
            msURL = ini.IniReadValue("MSSQL", "MS_URL");

            WelcomeMessage = ini.IniReadValue("WELCOME_MESSAGE", "WELCOME_MESSAGE");

            WelcomeMessage = WelcomeMessage.Replace("\\r", "\r");

            myUser = ini.IniReadValue("MYSQL", "MY_USER");
            myPass = ini.IniReadValue("MYSQL", "MY_PASS");
            myURL = ini.IniReadValue("MYSQL", "MY_URL");

            serverPORT = ini.IniReadValue("SERVER", "PORT");
            //ServerEchoStr = ini.IniReadValue("SERVER_ECHO", "ECHO_STRING");
            cFlag = System.Convert.ToInt32( ini.IniReadValue("CONNECT_FLAG", "FLAG") );

            NumberofClients = 0;

            string path = @"LOG";

            try
            {
                // Determine whether the directory exists.
                if (!Directory.Exists(path))
                {
                    // Try to create the directory.
                    DirectoryInfo di = Directory.CreateDirectory(path);
                    Console.WriteLine("Log Created {0}.", Directory.GetCreationTime(path));
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("The process failed: {0}", e.ToString());
            } 

            tcpListener = new TcpListener(IPAddress.Any, System.Convert.ToInt16(serverPORT));
            listenThread = new Thread(new ThreadStart(ListenForClients));
            listenThread.Start();
        }
    }
}
